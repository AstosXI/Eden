# debuff

Allows players to cancel buffs/debuffs via a slash command. 